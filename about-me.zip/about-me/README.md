# about me

A Pen created on CodePen.io. Original URL: [https://codepen.io/seannn1412/pen/zYmGbRZ](https://codepen.io/seannn1412/pen/zYmGbRZ).

